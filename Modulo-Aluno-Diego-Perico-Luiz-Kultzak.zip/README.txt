M�DULO CONTROLE

Primeiramente devemos executar a classe servidor que est� no pacote 
controle que est� no projeto servidor.

Na sequencia executa-se a classe login que est� no pacote IU no projeto
Client.

Deve ser fornecido o IP 127.0.0.1 e Porta 4321
usuario = usuario
senha = senha

M�DULO EVENTO

Para se cadastrar um evento, deve-se entrar no menu manter evento e selecionar
a op��o cadastrar.
Apos inserir as informa��es do envento, clique no bot�o "Salvar".
Para alterar/excluir um evento, basta selecionar a op��o Alterar/Excluir no
Manter evento. Logo aparecer� uma tela contento os eventos cadastrados, ap�s
a sele��o do evento desejado, pode-se excluir o enveto clicando no bot�o
"Excluir" ou clicar no bot�o "Selecionar" para realizar altera��es nos dados
do evento.
Ap�s alteradas as infoma��es, basta clicar no bot�o "Alterar".

M�DULO ALUNO

Primeiramente deve-se ir na op��o do menu MANTER ALUNO e selecionar a op��o cadastrar,
Apos inserir as informa��es do aluno, clique no bot�o "Cadastrar". 

Para alterar/excluir um aluno, basta selecionar a op��o Alterar/Excluir no
Manter aluno. Logo aparecer� uma tela contento os alunos cadastrados, ap�s
a sele��o do aluno desejado, pode-se excluir o aluno clicando no bot�o
"Excluir" ou clicar no bot�o "Selecionar" para realizar altera��es nos dados
do aluno.
Ap�s alteradas as infoma��es, basta clicar no bot�o "Alterar".
