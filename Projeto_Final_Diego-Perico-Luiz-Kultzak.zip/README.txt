M�DULO CONTROLE

Primeiramente devemos executar a classe servidor que est� no pacote 
controle que est� no projeto servidor.

Na sequencia executa-se a classe login que est� no pacote IU no projeto
Client.

Deve ser fornecido o IP 127.0.0.1 e Porta 4321
usuario = usuario
senha = senha

Modulo de Sorteio

Para utilizar esse m�dulo basta selecionar a opcao de sorteio, em seguida escolher o evento, para finalizar basta clicar no bot�o sortear e ser� apresentado o nome do vencedor.
